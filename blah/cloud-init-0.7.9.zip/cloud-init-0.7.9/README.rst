==================================
Cloud-init unofficial project fork
==================================


.. image:: https://readthedocs.org/projects/cloudinit/badge/?version=latest
   :target: http://cloudinit.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://travis-ci.org/blackboxsw/cloud-init.svg?branch=master
   :target: https://travis-ci.org/blackboxsw/cloud-init

Placeholder for more official documentation and some more docs
