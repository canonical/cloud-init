# This file is part of cloud-init. See LICENSE file for license information.

"""
Test verifiers for cloud-init bugs
See configs/bugs/README.md for more information
"""

# vi: ts=4 expandtab
