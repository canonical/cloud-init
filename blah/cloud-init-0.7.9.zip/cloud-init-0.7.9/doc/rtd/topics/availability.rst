************
Availability
************

It is currently installed in the `Ubuntu Cloud Images`_ and also in the official `Ubuntu`_ images available on EC2, Azure, GCE and many other clouds.

Versions for other systems can be (or have been) created for the following distributions:

- Ubuntu
- Fedora
- Debian
- RHEL
- CentOS
- *and more...*

So ask your distribution provider where you can obtain an image with it built-in if one is not already available ☺


.. _Ubuntu Cloud Images: http://cloud-images.ubuntu.com/
.. _Ubuntu: http://www.ubuntu.com/
.. vi: textwidth=78
